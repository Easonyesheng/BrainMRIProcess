# BrainMRIProcess
 Process Brain MRI Image including:   
    1 getting rid of skull  
    2 Brain part segmentation  


# Environment  
    macOS Mojave 10.14.6  
    python 3.7  
    python-opencv 4.1.2  
    pyqt5  

# Run  
    python BrainProcessing.py  


